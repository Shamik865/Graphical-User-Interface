classdef COVID_Data
    
    properties
        Name
        Comulitive_cases
        Daily_cases
        Comulitive_deaths
        Daily_deaths
        States
    end
    
    methods
        function obj = COVID_Data(zone_COVID_Data,zone_name,country_states)
            obj.Name = zone_name;
            if ~isempty(zone_COVID_Data)
                zone_COVID_Data = cell2mat(zone_COVID_Data);
                obj.Comulitive_cases = zone_COVID_Data(1:2:end-1);
                obj.Daily_cases = [zone_COVID_Data(1) minus(zone_COVID_Data(3:2:end-1),zone_COVID_Data(1:2:end-3))];
                obj.Comulitive_deaths = zone_COVID_Data(2:2:end);
                obj.Daily_deaths = [zone_COVID_Data(2) minus(zone_COVID_Data(4:2:end),zone_COVID_Data(2:2:end-2))];
            end
            if ~isempty(country_states)
                obj.States = country_states; 
            end
        end
    end
end